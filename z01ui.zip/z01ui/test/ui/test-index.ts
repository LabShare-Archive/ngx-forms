// import { UserAppComponent } from './app/user-app/user-app.component';
// import { bootstrap } from '@angular/bootstrap';
// import { HttpModule } from '@angular/http';
// import { HashLocationStrategy, LocationStrategy } from '@angular/common';
//import { ROUTER_PROVIDERS, PathLocationStrategy } from '@angular/router-deprecated';
// import { provide } from '@angular/core';

// bootstrap(UserAppComponent, [
//     HttpModule,
//     ROUTER_PROVIDERS,
//     provide(LocationStrategy, { useClass: HashLocationStrategy })
// ]);
import 'rxjs/add/operator/map';
declare let Zone: any;
