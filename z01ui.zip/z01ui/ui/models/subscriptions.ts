export class Subscription {
    public id?: number;
    public userId?: number;
    public projectId?: number;
   
}